-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2025 at 07:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dicom_viewer_v2_production`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_cleanup_expired_sessions` ()   BEGIN
    DELETE FROM `sessions` WHERE `expires_at` < NOW();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_cleanup_old_audit_logs` ()   BEGIN
    DELETE FROM `audit_logs`
    WHERE `created_at` < DATE_SUB(NOW(), INTERVAL 90 DAY);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_cleanup_old_backups` ()   BEGIN
    DECLARE retention INT;

    SELECT `retention_days` INTO retention
    FROM `gdrive_backup_config`
    LIMIT 1;

    DELETE FROM `backup_history`
    WHERE `created_at` < DATE_SUB(NOW(), INTERVAL retention DAY);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `resource_type` varchar(50) DEFAULT NULL,
  `resource_id` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `backup_history`
--

CREATE TABLE `backup_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `backup_type` enum('manual','scheduled') DEFAULT 'manual',
  `backup_name` varchar(255) NOT NULL,
  `gdrive_file_id` varchar(255) DEFAULT NULL,
  `file_size_bytes` bigint(20) DEFAULT 0,
  `includes_database` tinyint(1) DEFAULT 1,
  `includes_php` tinyint(1) DEFAULT 1,
  `includes_js` tinyint(1) DEFAULT 1,
  `includes_config` tinyint(1) DEFAULT 1,
  `status` enum('success','failed','partial') DEFAULT 'success',
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clinical_notes`
--

CREATE TABLE `clinical_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `study_uid` varchar(255) NOT NULL,
  `series_uid` varchar(255) DEFAULT NULL,
  `instance_uid` varchar(255) DEFAULT NULL,
  `note_type` enum('clinical_history','series_note','image_note','general') DEFAULT 'general',
  `content` text NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gdrive_backup_config`
--

CREATE TABLE `gdrive_backup_config` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `refresh_token` text DEFAULT NULL,
  `folder_name` varchar(255) DEFAULT 'DICOM_Viewer_Backups',
  `folder_id` varchar(255) DEFAULT NULL,
  `backup_enabled` tinyint(1) DEFAULT 0,
  `backup_schedule` enum('daily','weekly','monthly') DEFAULT 'daily',
  `backup_time` time DEFAULT '02:00:00',
  `backup_database` tinyint(1) DEFAULT 1,
  `backup_php_files` tinyint(1) DEFAULT 1,
  `backup_js_files` tinyint(1) DEFAULT 1,
  `backup_config_files` tinyint(1) DEFAULT 1,
  `retention_days` int(11) DEFAULT 30,
  `last_backup_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gdrive_backup_config`
--

INSERT INTO `gdrive_backup_config` (`id`, `client_id`, `client_secret`, `refresh_token`, `folder_name`, `folder_id`, `backup_enabled`, `backup_schedule`, `backup_time`, `backup_database`, `backup_php_files`, `backup_js_files`, `backup_config_files`, `retention_days`, `last_backup_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, 'DICOM_Viewer_Backups', NULL, 0, 'daily', '02:00:00', 1, 1, 1, 1, 30, NULL, '2025-11-22 13:22:59');

-- --------------------------------------------------------

--
-- Table structure for table `import_history`
--

CREATE TABLE `import_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_id` int(10) UNSIGNED DEFAULT NULL,
  `file_path` varchar(1000) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size_bytes` bigint(20) NOT NULL,
  `file_hash` varchar(64) DEFAULT NULL,
  `orthanc_instance_id` varchar(255) DEFAULT NULL,
  `patient_id` varchar(64) DEFAULT NULL,
  `study_uid` varchar(255) DEFAULT NULL,
  `series_uid` varchar(255) DEFAULT NULL,
  `instance_uid` varchar(255) DEFAULT NULL,
  `status` enum('imported','failed','duplicate','skipped') DEFAULT 'imported',
  `error_message` text DEFAULT NULL,
  `imported_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `import_jobs`
--

CREATE TABLE `import_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_type` enum('initial','incremental','manual') DEFAULT 'manual',
  `source_path` varchar(500) NOT NULL,
  `total_files` int(11) DEFAULT 0,
  `files_processed` int(11) DEFAULT 0,
  `files_imported` int(11) DEFAULT 0,
  `files_failed` int(11) DEFAULT 0,
  `total_size_bytes` bigint(20) DEFAULT 0,
  `status` enum('pending','running','completed','failed','cancelled') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `measurements`
--

CREATE TABLE `measurements` (
  `id` int(10) UNSIGNED NOT NULL,
  `study_uid` varchar(255) NOT NULL,
  `series_uid` varchar(255) NOT NULL,
  `instance_uid` varchar(255) NOT NULL,
  `tool_type` enum('length','angle','rectangle_roi','elliptical_roi','freehand_roi','probe') NOT NULL,
  `measurement_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`measurement_data`)),
  `value` varchar(100) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medical_reports`
--

CREATE TABLE `medical_reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `study_uid` varchar(255) NOT NULL,
  `patient_id` varchar(64) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `template_name` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `indication` text DEFAULT NULL,
  `technique` text DEFAULT NULL,
  `findings` text DEFAULT NULL,
  `impression` text DEFAULT NULL,
  `reporting_physician_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('draft','final','amended') DEFAULT 'draft',
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `finalized_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(10) UNSIGNED NOT NULL,
  `study_uid` varchar(255) NOT NULL,
  `patient_id` varchar(64) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `medication_name` varchar(255) NOT NULL,
  `dosage` varchar(100) NOT NULL,
  `frequency` varchar(100) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `instructions` text DEFAULT NULL,
  `prescribed_by` int(10) UNSIGNED NOT NULL,
  `prescribed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','completed','cancelled') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_versions`
--

CREATE TABLE `report_versions` (
  `id` int(10) UNSIGNED NOT NULL,
  `report_id` int(10) UNSIGNED NOT NULL,
  `version_number` int(10) UNSIGNED NOT NULL,
  `indication` text DEFAULT NULL,
  `technique` text DEFAULT NULL,
  `findings` text DEFAULT NULL,
  `impression` text DEFAULT NULL,
  `changed_by` int(10) UNSIGNED NOT NULL,
  `change_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `session_id` varchar(128) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sync_configuration`
--

CREATE TABLE `sync_configuration` (
  `id` int(10) UNSIGNED NOT NULL,
  `orthanc_storage_path` varchar(500) NOT NULL,
  `hospital_data_path` varchar(500) DEFAULT NULL,
  `ftp_host` varchar(255) DEFAULT NULL,
  `ftp_username` varchar(100) DEFAULT NULL,
  `ftp_password` varchar(255) DEFAULT NULL,
  `ftp_port` int(11) DEFAULT 21,
  `ftp_path` varchar(500) DEFAULT '/public_html/dicom_viewer/',
  `ftp_passive` tinyint(1) DEFAULT 1,
  `sync_enabled` tinyint(1) DEFAULT 0,
  `sync_interval` int(11) DEFAULT 120,
  `monitoring_enabled` tinyint(1) DEFAULT 0,
  `monitoring_interval` int(11) DEFAULT 30,
  `last_sync_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sync_configuration`
--

INSERT INTO `sync_configuration` (`id`, `orthanc_storage_path`, `hospital_data_path`, `ftp_host`, `ftp_username`, `ftp_password`, `ftp_port`, `ftp_path`, `ftp_passive`, `sync_enabled`, `sync_interval`, `monitoring_enabled`, `monitoring_interval`, `last_sync_at`, `updated_at`) VALUES
(1, 'C:\\Orthanc\\OrthancStorage', NULL, NULL, NULL, NULL, 21, '/public_html/dicom_viewer/', 1, 0, 120, 0, 30, NULL, '2025-11-22 13:22:59');

-- --------------------------------------------------------

--
-- Table structure for table `sync_history`
--

CREATE TABLE `sync_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sync_type` enum('manual','scheduled','monitoring') DEFAULT 'manual',
  `destination` enum('localhost','godaddy','both') DEFAULT 'both',
  `files_synced` int(11) DEFAULT 0,
  `total_size_bytes` bigint(20) DEFAULT 0,
  `status` enum('success','failed','partial') DEFAULT 'success',
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` enum('admin','radiologist','technician','viewer') DEFAULT 'viewer',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$12$Aa5XJ5jZH.TH9f1Z8EHiEeVW2JhuQ.69hx6/.y.PUID2.sGCRVa1i', 'System Administrator', 'admin@hospital.com', 'admin', 1, NULL, '2025-11-22 13:22:59', '2025-11-23 06:28:49'),
(2, 'radiologist', '$2y$12$FlxZAVkMcKyHxcffXp7b8.ohSle96MZmG0DIKuR9q2SWaVT56jVam', 'Dr. John Smith', 'radiologist@hospital.com', 'radiologist', 1, NULL, '2025-11-22 13:22:59', '2025-11-23 06:28:50'),
(3, 'technician', '$2y$12$jr6cdvV7D88sbIjNTs8TE.eJU0WzfnNbg/X4bky6C.2o9pDWRkNlW', 'Sarah Johnson', 'technician@hospital.com', 'technician', 1, NULL, '2025-11-22 13:22:59', '2025-11-23 06:28:51');

-- --------------------------------------------------------

--
-- Table structure for table `user_preferences`
--

CREATE TABLE `user_preferences` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `preference_key` varchar(100) NOT NULL,
  `preference_value` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_active_reports`
-- (See below for the actual view)
--
CREATE TABLE `vw_active_reports` (
`id` int(10) unsigned
,`study_uid` varchar(255)
,`patient_id` varchar(64)
,`patient_name` varchar(255)
,`template_name` varchar(100)
,`title` varchar(255)
,`status` enum('draft','final','amended')
,`created_by_name` varchar(255)
,`reporting_physician_name` varchar(255)
,`created_at` timestamp
,`updated_at` timestamp
,`finalized_at` timestamp
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_audit_trail`
-- (See below for the actual view)
--
CREATE TABLE `vw_audit_trail` (
`id` bigint(20) unsigned
,`username` varchar(50)
,`full_name` varchar(255)
,`action` varchar(100)
,`resource_type` varchar(50)
,`resource_id` varchar(255)
,`ip_address` varchar(45)
,`created_at` timestamp
);

-- --------------------------------------------------------

--
-- Structure for view `vw_active_reports`
--
DROP TABLE IF EXISTS `vw_active_reports`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_active_reports`  AS SELECT `r`.`id` AS `id`, `r`.`study_uid` AS `study_uid`, `r`.`patient_id` AS `patient_id`, `r`.`patient_name` AS `patient_name`, `r`.`template_name` AS `template_name`, `r`.`title` AS `title`, `r`.`status` AS `status`, `u1`.`full_name` AS `created_by_name`, `u2`.`full_name` AS `reporting_physician_name`, `r`.`created_at` AS `created_at`, `r`.`updated_at` AS `updated_at`, `r`.`finalized_at` AS `finalized_at` FROM ((`medical_reports` `r` left join `users` `u1` on(`r`.`created_by` = `u1`.`id`)) left join `users` `u2` on(`r`.`reporting_physician_id` = `u2`.`id`)) WHERE `r`.`status` in ('draft','final') ;

-- --------------------------------------------------------

--
-- Structure for view `vw_audit_trail`
--
DROP TABLE IF EXISTS `vw_audit_trail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_audit_trail`  AS SELECT `a`.`id` AS `id`, `a`.`username` AS `username`, `u`.`full_name` AS `full_name`, `a`.`action` AS `action`, `a`.`resource_type` AS `resource_type`, `a`.`resource_id` AS `resource_id`, `a`.`ip_address` AS `ip_address`, `a`.`created_at` AS `created_at` FROM (`audit_logs` `a` left join `users` `u` on(`a`.`user_id` = `u`.`id`)) ORDER BY `a`.`created_at` DESC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_resource_type` (`resource_type`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `backup_history`
--
ALTER TABLE `backup_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_backup_type` (`backup_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `clinical_notes`
--
ALTER TABLE `clinical_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_study_uid` (`study_uid`),
  ADD KEY `idx_series_uid` (`series_uid`),
  ADD KEY `idx_note_type` (`note_type`),
  ADD KEY `idx_created_by` (`created_by`);

--
-- Indexes for table `gdrive_backup_config`
--
ALTER TABLE `gdrive_backup_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `import_history`
--
ALTER TABLE `import_history`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_file_hash` (`file_hash`),
  ADD KEY `idx_job_id` (`job_id`),
  ADD KEY `idx_file_path` (`file_path`(255)),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_imported_at` (`imported_at`);

--
-- Indexes for table `import_jobs`
--
ALTER TABLE `import_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `measurements`
--
ALTER TABLE `measurements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_study_uid` (`study_uid`),
  ADD KEY `idx_series_uid` (`series_uid`),
  ADD KEY `idx_instance_uid` (`instance_uid`),
  ADD KEY `idx_tool_type` (`tool_type`),
  ADD KEY `idx_created_by` (`created_by`);

--
-- Indexes for table `medical_reports`
--
ALTER TABLE `medical_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_study_uid` (`study_uid`),
  ADD KEY `idx_patient_id` (`patient_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_reporting_physician` (`reporting_physician_id`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_study_uid` (`study_uid`),
  ADD KEY `idx_patient_id` (`patient_id`),
  ADD KEY `idx_prescribed_by` (`prescribed_by`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `report_versions`
--
ALTER TABLE `report_versions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `changed_by` (`changed_by`),
  ADD KEY `idx_report_id` (`report_id`),
  ADD KEY `idx_version_number` (`version_number`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `session_id` (`session_id`),
  ADD KEY `idx_session_id` (`session_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- Indexes for table `sync_configuration`
--
ALTER TABLE `sync_configuration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sync_history`
--
ALTER TABLE `sync_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sync_type` (`sync_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_started_at` (`started_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_preference` (`user_id`,`preference_key`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `backup_history`
--
ALTER TABLE `backup_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clinical_notes`
--
ALTER TABLE `clinical_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gdrive_backup_config`
--
ALTER TABLE `gdrive_backup_config`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `import_history`
--
ALTER TABLE `import_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `import_jobs`
--
ALTER TABLE `import_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `measurements`
--
ALTER TABLE `measurements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medical_reports`
--
ALTER TABLE `medical_reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_versions`
--
ALTER TABLE `report_versions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sync_configuration`
--
ALTER TABLE `sync_configuration`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sync_history`
--
ALTER TABLE `sync_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_preferences`
--
ALTER TABLE `user_preferences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `clinical_notes`
--
ALTER TABLE `clinical_notes`
  ADD CONSTRAINT `clinical_notes_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `import_history`
--
ALTER TABLE `import_history`
  ADD CONSTRAINT `import_history_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `import_jobs` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `measurements`
--
ALTER TABLE `measurements`
  ADD CONSTRAINT `measurements_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `medical_reports`
--
ALTER TABLE `medical_reports`
  ADD CONSTRAINT `medical_reports_ibfk_1` FOREIGN KEY (`reporting_physician_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `medical_reports_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD CONSTRAINT `prescriptions_ibfk_1` FOREIGN KEY (`prescribed_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `report_versions`
--
ALTER TABLE `report_versions`
  ADD CONSTRAINT `report_versions_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `medical_reports` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `report_versions_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD CONSTRAINT `user_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `evt_cleanup_sessions` ON SCHEDULE EVERY 1 HOUR STARTS '2025-11-22 18:52:59' ON COMPLETION NOT PRESERVE ENABLE DO CALL sp_cleanup_expired_sessions()$$

CREATE DEFINER=`root`@`localhost` EVENT `evt_cleanup_audit_logs` ON SCHEDULE EVERY 1 DAY STARTS '2025-01-01 03:00:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL sp_cleanup_old_audit_logs()$$

CREATE DEFINER=`root`@`localhost` EVENT `evt_cleanup_backups` ON SCHEDULE EVERY 1 DAY STARTS '2025-01-01 04:00:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL sp_cleanup_old_backups()$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
