-- DICOM Viewer Database Backup
-- Generated: 2025-11-25 20:09:17

SET FOREIGN_KEY_CHECKS=0;

-- Table: audit_logs
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `resource_type` varchar(50) DEFAULT NULL,
  `resource_id` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_resource_type` (`resource_type`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: audit_logs
INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `resource_type`, `resource_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('1', '1', 'admin', 'list', 'medical_report', NULL, 'Retrieved 0 medical report(s) for study 1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-25 19:29:07');
INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `resource_type`, `resource_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('2', '1', 'admin', 'list', 'medical_report', NULL, 'Retrieved 0 medical report(s) for study 1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-25 19:29:48');
INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `resource_type`, `resource_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('3', '1', 'admin', 'list', 'medical_report', NULL, 'Retrieved 0 medical report(s) for study 1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-25 19:29:51');
INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `resource_type`, `resource_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('4', '1', 'admin', 'create', 'medical_report', '9', 'Created medical report \'Medical Report\' for study 1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-25 19:30:01');
INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `resource_type`, `resource_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('5', '1', 'admin', 'list', 'medical_report', NULL, 'Retrieved 1 medical report(s) for study 1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-25 19:30:01');
INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `resource_type`, `resource_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('6', '1', 'admin', 'list', 'medical_report', NULL, 'Retrieved 1 medical report(s) for study 1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-25 19:30:05');
INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `resource_type`, `resource_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('7', '1', 'admin', 'list', 'medical_report', NULL, 'Retrieved 1 medical report(s) for study 1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-25 19:30:39');

-- Table: backup_accounts
DROP TABLE IF EXISTS `backup_accounts`;
CREATE TABLE `backup_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) NOT NULL COMMENT 'Friendly name for the account',
  `credentials_json` text NOT NULL COMMENT 'Google service account credentials',
  `service_account_email` varchar(255) NOT NULL,
  `folder_name` varchar(255) DEFAULT 'DICOM_Viewer_Backups',
  `is_active` tinyint(1) DEFAULT 1 COMMENT '1=active, 0=disabled',
  `last_backup_date` datetime DEFAULT NULL,
  `last_backup_status` varchar(50) DEFAULT NULL COMMENT 'success, failed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `last_backup_date` (`last_backup_date`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: backup_accounts
INSERT INTO `backup_accounts` (`id`, `account_name`, `credentials_json`, `service_account_email`, `folder_name`, `is_active`, `last_backup_date`, `last_backup_status`, `created_at`, `updated_at`) VALUES ('3', 'Drive', '{\"type\":\"service_account\",\"project_id\":\"dicom-backup\",\"private_key_id\":\"dde236d8a2c9b364275572807400e67151b34cf3\",\"private_key\":\"-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDRJr7IF1dyC0xa\\n4YzXQoW0UqQNMZmoROCwZxcL0wYYSYIxcM33GO5LOoUvX7WnEfRDGeWjIa5U75wM\\nSfa7lI8CXEpslLjvIqPAxBiD33S7tNXru5BJdAKYcwK3XsaZqApUrh7ykvkV0VvL\\nW18t7eSqnBzMV2VKqrACSBq1tUNhRWChpuuIrSnbmpzg8xtLLm+oaF2p\\/96tdJUE\\nyYe0JuYLxOy5InhxtOQc+vGPgcdAptXfmCl6bzru8dj1yg3FxGMoma0Fdt2pJF4t\\nCzVTCYNDTtv98RovZAmIG05VCuZ0vynMeaTZjpFzYAOFOhjARJ+Op8w8Ugfi1RDr\\nwyHYVqwxAgMBAAECggEADlb8YvZMEI2lwTVlqqdCSN1sUgXskGo93YUJQiOdxLHa\\n3fjrUN3CDiEHsKUnQeUr53iHE2rjwP8MppW2TPYf4qbhPhXporuv7oTYtBybVvih\\nvMqHV1c\\/i6RBs2t+wlo7GxiKa\\/yXsgnrTpiygJD8SeuaLd3FcXEdJYrmtJP7oqzh\\n3u3+SDyTxv3Bn5AAMhNSXsCJDtFgKLhauevsKEg90TiDwkduLiLko+gvDM+eZzRe\\n0RRtdPpWDp5oaZe2N5F1Rkp1zebwf7KhfZ08Ism4EIl6nAEYCtEmDczFyf3gBGQ0\\n0RQJzxzBD6naRl40kiyGlVPeUFtENFjkTcJAsqmX4QKBgQD7cuwNoRIZbok7GRE6\\n5VSz39SuFHZIiMtyLNJ\\/Ue\\/EY\\/znBvUeLkrBM08U2KYbtvYWaWnXT1jQNMRUL8vk\\nvFavHtFL0gLflej8sYomblZan3hahrkBOQdb7ZoylP6vNF15rjRv5MiZwLjiD7af\\nq4WYGXIgzRcwdWZceNXq5+nMJwKBgQDU79bUIVPiff8dkMqlLeRrS4ahfdmPL9\\/J\\nOlcCXu0ZN0wRignGbF\\/MiJ4sClfDwvYj4UIAzmw8VaaCV6941yiah0qAU2RIcik7\\nykaeKTCkLnYA7OemCIaPlN+1HeIEYM4\\/irLjCfkoXgOyYvNt0RNOdHZV9jRaQpoe\\nknVHXw0D5wKBgEnYi2jJSBZ99wGLMBs65LBa6Qwi6EYPHqiubzeDKcZkkw6KZYxy\\njfPFjNETe10iU41rcfEQ1YV4KbyLuPa5NUAC7fa1e7CMRzuHLIpy1xuQP\\/leHZE1\\nXWrrEeEPDukHmPg2aCIAb8Vv6xxA\\/yJPblGoD3OAp\\/HMWL6JolF1wJz7AoGBAJ6I\\npkAvQ\\/334q2HdGhAX7TGeUjYotapRQrThZ49QHcqpVbVl+uEGlr0SBbv6GHWUF1s\\nQzDIfur4tcyLLhhg0FkkawJZk+sgG7TpJ2RvtEg4UyDjQKBr7osNwvRceD7cOBI0\\n2HSSo087l7MDWsujAqXBrazYbifZOFeUoP5vNQh3AoGBAOhyFhtEVbE335GZ8nND\\niXsctVG8SmHBn7+47FLLsMHdupFEVqvJUMy7QLW2zFs5Cyd9o0MsoQgtm0vgzCmu\\n9xUrBNxoIW8C+HSV6esgWXE+pGRtM4b7TK3Kpcs05U\\/ajVDzRcjVkEt5Wm3Cz+SH\\nE\\/2+gde6OAtsfnkLpswHGIcC\\n-----END PRIVATE KEY-----\\n\",\"client_email\":\"dicom-backup-service@dicom-backup.iam.gserviceaccount.com\",\"client_id\":\"117277588561687136612\",\"auth_uri\":\"https:\\/\\/accounts.google.com\\/o\\/oauth2\\/auth\",\"token_uri\":\"https:\\/\\/oauth2.googleapis.com\\/token\",\"auth_provider_x509_cert_url\":\"https:\\/\\/www.googleapis.com\\/oauth2\\/v1\\/certs\",\"client_x509_cert_url\":\"https:\\/\\/www.googleapis.com\\/robot\\/v1\\/metadata\\/x509\\/dicom-backup-service%40dicom-backup.iam.gserviceaccount.com\",\"universe_domain\":\"googleapis.com\"}', 'dicom-backup-service@dicom-backup.iam.gserviceaccount.com', 'DICOM_Viewer_Backups', '1', '2025-11-25 20:09:09', 'PHP Error: Class \"ZipArchive\" not found', '2025-11-25 20:09:05', '2025-11-25 20:09:09');

-- Table: backup_history
DROP TABLE IF EXISTS `backup_history`;
CREATE TABLE `backup_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_type` enum('manual','scheduled') DEFAULT 'manual',
  `backup_name` varchar(255) NOT NULL,
  `gdrive_file_id` varchar(255) DEFAULT NULL,
  `file_size_bytes` bigint(20) DEFAULT 0,
  `includes_database` tinyint(1) DEFAULT 1,
  `includes_php` tinyint(1) DEFAULT 1,
  `includes_js` tinyint(1) DEFAULT 1,
  `includes_config` tinyint(1) DEFAULT 1,
  `status` enum('success','failed','partial') DEFAULT 'success',
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_backup_type` (`backup_type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: backup_schedule_config
DROP TABLE IF EXISTS `backup_schedule_config`;
CREATE TABLE `backup_schedule_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_enabled` tinyint(1) DEFAULT 1,
  `interval_hours` int(11) DEFAULT 6 COMMENT 'Backup every X hours',
  `next_backup_time` datetime DEFAULT NULL,
  `last_run_time` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: backup_schedule_config
INSERT INTO `backup_schedule_config` (`id`, `schedule_enabled`, `interval_hours`, `next_backup_time`, `last_run_time`, `created_at`, `updated_at`) VALUES ('1', '1', '1', '2025-11-25 15:13:59', NULL, '2025-11-25 16:33:37', '2025-11-25 19:43:59');

-- Table: cached_patients
DROP TABLE IF EXISTS `cached_patients`;
CREATE TABLE `cached_patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orthanc_id` varchar(255) NOT NULL,
  `patient_id` varchar(255) NOT NULL,
  `patient_name` varchar(255) DEFAULT NULL,
  `patient_birth_date` date DEFAULT NULL,
  `patient_sex` varchar(10) DEFAULT NULL,
  `study_count` int(11) DEFAULT 0,
  `last_study_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `orthanc_id` (`orthanc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: cached_patients
INSERT INTO `cached_patients` (`id`, `orthanc_id`, `patient_id`, `patient_name`, `patient_birth_date`, `patient_sex`, `study_count`, `last_study_date`, `created_at`, `updated_at`) VALUES ('1', 'b6589fc6-ab0dc82c-f12099d1-c2d40ab9-94e8410c', '0', 'Anonymized^^', NULL, 'M', '1', '2015-12-07', '2025-11-25 19:28:56', '2025-11-25 19:28:57');

-- Table: cached_studies
DROP TABLE IF EXISTS `cached_studies`;
CREATE TABLE `cached_studies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `study_instance_uid` varchar(255) NOT NULL,
  `orthanc_id` varchar(255) NOT NULL,
  `patient_id` varchar(255) NOT NULL,
  `study_date` date DEFAULT NULL,
  `study_time` varchar(20) DEFAULT NULL,
  `study_description` varchar(255) DEFAULT NULL,
  `accession_number` varchar(255) DEFAULT NULL,
  `modality` varchar(50) DEFAULT NULL,
  `series_count` int(11) DEFAULT 0,
  `instance_count` int(11) DEFAULT 0,
  `instances_count` int(11) DEFAULT 0,
  `last_synced` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_starred` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `study_instance_uid` (`study_instance_uid`),
  KEY `patient_id` (`patient_id`),
  KEY `orthanc_id` (`orthanc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: cached_studies
INSERT INTO `cached_studies` (`id`, `study_instance_uid`, `orthanc_id`, `patient_id`, `study_date`, `study_time`, `study_description`, `accession_number`, `modality`, `series_count`, `instance_count`, `instances_count`, `last_synced`, `created_at`, `updated_at`, `is_starred`) VALUES ('1', '1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', 'a2390fab-3be3e31b-268f6c22-4eb2e70f-6e5d1726', '0', '2015-12-07', '07:31:53', 'KUNAS', '', 'CT', '1', '2', '0', '2025-11-25 19:28:57', '2025-11-25 19:28:57', '2025-11-25 19:28:57', '0');

-- Table: clinical_notes
DROP TABLE IF EXISTS `clinical_notes`;
CREATE TABLE `clinical_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `study_uid` varchar(255) NOT NULL,
  `series_uid` varchar(255) DEFAULT NULL,
  `instance_uid` varchar(255) DEFAULT NULL,
  `note_type` enum('clinical_history','series_note','image_note','general') DEFAULT 'general',
  `content` text NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_study_uid` (`study_uid`),
  KEY `idx_series_uid` (`series_uid`),
  KEY `idx_note_type` (`note_type`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `clinical_notes_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: dicom_nodes
DROP TABLE IF EXISTS `dicom_nodes`;
CREATE TABLE `dicom_nodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ae_title` varchar(64) NOT NULL,
  `host_name` varchar(255) NOT NULL,
  `port` int(11) NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: dicom_nodes
INSERT INTO `dicom_nodes` (`id`, `name`, `ae_title`, `host_name`, `port`, `is_default`, `created_at`, `updated_at`) VALUES ('1', 'Default Server', 'HOSPITAL_PACS', '0.0.0.0', '4242', '1', '2025-11-24 19:09:41', '2025-11-24 19:09:41');

-- Table: dicom_printers
DROP TABLE IF EXISTS `dicom_printers`;
CREATE TABLE `dicom_printers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ae_title` varchar(64) NOT NULL,
  `host_name` varchar(255) NOT NULL,
  `port` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: gdrive_backup_config
DROP TABLE IF EXISTS `gdrive_backup_config`;
CREATE TABLE `gdrive_backup_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `refresh_token` text DEFAULT NULL,
  `folder_name` varchar(255) DEFAULT 'DICOM_Viewer_Backups',
  `folder_id` varchar(255) DEFAULT NULL,
  `backup_enabled` tinyint(1) DEFAULT 0,
  `backup_schedule` enum('hourly','daily','weekly','monthly') DEFAULT 'daily',
  `backup_time` time DEFAULT '02:00:00',
  `backup_database` tinyint(1) DEFAULT 1,
  `backup_php_files` tinyint(1) DEFAULT 1,
  `backup_js_files` tinyint(1) DEFAULT 1,
  `backup_config_files` tinyint(1) DEFAULT 1,
  `retention_days` int(11) DEFAULT 30,
  `last_backup_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: gdrive_backup_config
INSERT INTO `gdrive_backup_config` (`id`, `client_id`, `client_secret`, `refresh_token`, `folder_name`, `folder_id`, `backup_enabled`, `backup_schedule`, `backup_time`, `backup_database`, `backup_php_files`, `backup_js_files`, `backup_config_files`, `retention_days`, `last_backup_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 'DICOM_Viewer_Backups', NULL, '1', 'hourly', '00:00:00', '1', '1', '1', '1', '30', NULL, '2025-11-25 19:57:24');

-- Table: hospital_data_config
DROP TABLE IF EXISTS `hospital_data_config`;
CREATE TABLE `hospital_data_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL,
  `config_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: hospital_data_config
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('1', 'import_directory_path', 'C:\\Users\\prash\\Downloads\\dicom\\series-000002', '2025-11-25 17:10:29');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('2', 'auto_import_enabled', '0', '2025-11-24 17:24:45');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('3', 'auto_import_interval_minutes', '30', '2025-11-24 17:24:45');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('4', 'backup_imported_files', '1', '2025-11-24 17:24:45');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('5', 'gdrive_auto_configure', '0', '2025-11-24 17:24:45');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('6', 'gdrive_credentials', '{\"type\":\"service_account\",\"project_id\":\"dicom-backup\",\"private_key_id\":\"dde236d8a2c9b364275572807400e67151b34cf3\",\"private_key\":\"-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDRJr7IF1dyC0xa\\n4YzXQoW0UqQNMZmoROCwZxcL0wYYSYIxcM33GO5LOoUvX7WnEfRDGeWjIa5U75wM\\nSfa7lI8CXEpslLjvIqPAxBiD33S7tNXru5BJdAKYcwK3XsaZqApUrh7ykvkV0VvL\\nW18t7eSqnBzMV2VKqrACSBq1tUNhRWChpuuIrSnbmpzg8xtLLm+oaF2p\\/96tdJUE\\nyYe0JuYLxOy5InhxtOQc+vGPgcdAptXfmCl6bzru8dj1yg3FxGMoma0Fdt2pJF4t\\nCzVTCYNDTtv98RovZAmIG05VCuZ0vynMeaTZjpFzYAOFOhjARJ+Op8w8Ugfi1RDr\\nwyHYVqwxAgMBAAECggEADlb8YvZMEI2lwTVlqqdCSN1sUgXskGo93YUJQiOdxLHa\\n3fjrUN3CDiEHsKUnQeUr53iHE2rjwP8MppW2TPYf4qbhPhXporuv7oTYtBybVvih\\nvMqHV1c\\/i6RBs2t+wlo7GxiKa\\/yXsgnrTpiygJD8SeuaLd3FcXEdJYrmtJP7oqzh\\n3u3+SDyTxv3Bn5AAMhNSXsCJDtFgKLhauevsKEg90TiDwkduLiLko+gvDM+eZzRe\\n0RRtdPpWDp5oaZe2N5F1Rkp1zebwf7KhfZ08Ism4EIl6nAEYCtEmDczFyf3gBGQ0\\n0RQJzxzBD6naRl40kiyGlVPeUFtENFjkTcJAsqmX4QKBgQD7cuwNoRIZbok7GRE6\\n5VSz39SuFHZIiMtyLNJ\\/Ue\\/EY\\/znBvUeLkrBM08U2KYbtvYWaWnXT1jQNMRUL8vk\\nvFavHtFL0gLflej8sYomblZan3hahrkBOQdb7ZoylP6vNF15rjRv5MiZwLjiD7af\\nq4WYGXIgzRcwdWZceNXq5+nMJwKBgQDU79bUIVPiff8dkMqlLeRrS4ahfdmPL9\\/J\\nOlcCXu0ZN0wRignGbF\\/MiJ4sClfDwvYj4UIAzmw8VaaCV6941yiah0qAU2RIcik7\\nykaeKTCkLnYA7OemCIaPlN+1HeIEYM4\\/irLjCfkoXgOyYvNt0RNOdHZV9jRaQpoe\\nknVHXw0D5wKBgEnYi2jJSBZ99wGLMBs65LBa6Qwi6EYPHqiubzeDKcZkkw6KZYxy\\njfPFjNETe10iU41rcfEQ1YV4KbyLuPa5NUAC7fa1e7CMRzuHLIpy1xuQP\\/leHZE1\\nXWrrEeEPDukHmPg2aCIAb8Vv6xxA\\/yJPblGoD3OAp\\/HMWL6JolF1wJz7AoGBAJ6I\\npkAvQ\\/334q2HdGhAX7TGeUjYotapRQrThZ49QHcqpVbVl+uEGlr0SBbv6GHWUF1s\\nQzDIfur4tcyLLhhg0FkkawJZk+sgG7TpJ2RvtEg4UyDjQKBr7osNwvRceD7cOBI0\\n2HSSo087l7MDWsujAqXBrazYbifZOFeUoP5vNQh3AoGBAOhyFhtEVbE335GZ8nND\\niXsctVG8SmHBn7+47FLLsMHdupFEVqvJUMy7QLW2zFs5Cyd9o0MsoQgtm0vgzCmu\\n9xUrBNxoIW8C+HSV6esgWXE+pGRtM4b7TK3Kpcs05U\\/ajVDzRcjVkEt5Wm3Cz+SH\\nE\\/2+gde6OAtsfnkLpswHGIcC\\n-----END PRIVATE KEY-----\\n\",\"client_email\":\"dicom-backup-service@dicom-backup.iam.gserviceaccount.com\",\"client_id\":\"117277588561687136612\",\"auth_uri\":\"https:\\/\\/accounts.google.com\\/o\\/oauth2\\/auth\",\"token_uri\":\"https:\\/\\/oauth2.googleapis.com\\/token\",\"auth_provider_x509_cert_url\":\"https:\\/\\/www.googleapis.com\\/oauth2\\/v1\\/certs\",\"client_x509_cert_url\":\"https:\\/\\/www.googleapis.com\\/robot\\/v1\\/metadata\\/x509\\/dicom-backup-service%40dicom-backup.iam.gserviceaccount.com\",\"universe_domain\":\"googleapis.com\"}', '2025-11-25 16:21:19');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('7', 'gdrive_folder_name', 'DICOM_Viewer_Backups', '2025-11-25 16:21:19');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('8', 'gdrive_service_account_email', 'dicom-backup-service@dicom-backup.iam.gserviceaccount.com', '2025-11-25 16:21:19');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('9', 'gdrive_configured', 'true', '2025-11-25 16:21:19');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('28', 'temp_gdrive_credentials', '{\"type\":\"service_account\",\"project_id\":\"dicom-backup\",\"private_key_id\":\"dde236d8a2c9b364275572807400e67151b34cf3\",\"private_key\":\"-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDRJr7IF1dyC0xa\\n4YzXQoW0UqQNMZmoROCwZxcL0wYYSYIxcM33GO5LOoUvX7WnEfRDGeWjIa5U75wM\\nSfa7lI8CXEpslLjvIqPAxBiD33S7tNXru5BJdAKYcwK3XsaZqApUrh7ykvkV0VvL\\nW18t7eSqnBzMV2VKqrACSBq1tUNhRWChpuuIrSnbmpzg8xtLLm+oaF2p\\/96tdJUE\\nyYe0JuYLxOy5InhxtOQc+vGPgcdAptXfmCl6bzru8dj1yg3FxGMoma0Fdt2pJF4t\\nCzVTCYNDTtv98RovZAmIG05VCuZ0vynMeaTZjpFzYAOFOhjARJ+Op8w8Ugfi1RDr\\nwyHYVqwxAgMBAAECggEADlb8YvZMEI2lwTVlqqdCSN1sUgXskGo93YUJQiOdxLHa\\n3fjrUN3CDiEHsKUnQeUr53iHE2rjwP8MppW2TPYf4qbhPhXporuv7oTYtBybVvih\\nvMqHV1c\\/i6RBs2t+wlo7GxiKa\\/yXsgnrTpiygJD8SeuaLd3FcXEdJYrmtJP7oqzh\\n3u3+SDyTxv3Bn5AAMhNSXsCJDtFgKLhauevsKEg90TiDwkduLiLko+gvDM+eZzRe\\n0RRtdPpWDp5oaZe2N5F1Rkp1zebwf7KhfZ08Ism4EIl6nAEYCtEmDczFyf3gBGQ0\\n0RQJzxzBD6naRl40kiyGlVPeUFtENFjkTcJAsqmX4QKBgQD7cuwNoRIZbok7GRE6\\n5VSz39SuFHZIiMtyLNJ\\/Ue\\/EY\\/znBvUeLkrBM08U2KYbtvYWaWnXT1jQNMRUL8vk\\nvFavHtFL0gLflej8sYomblZan3hahrkBOQdb7ZoylP6vNF15rjRv5MiZwLjiD7af\\nq4WYGXIgzRcwdWZceNXq5+nMJwKBgQDU79bUIVPiff8dkMqlLeRrS4ahfdmPL9\\/J\\nOlcCXu0ZN0wRignGbF\\/MiJ4sClfDwvYj4UIAzmw8VaaCV6941yiah0qAU2RIcik7\\nykaeKTCkLnYA7OemCIaPlN+1HeIEYM4\\/irLjCfkoXgOyYvNt0RNOdHZV9jRaQpoe\\nknVHXw0D5wKBgEnYi2jJSBZ99wGLMBs65LBa6Qwi6EYPHqiubzeDKcZkkw6KZYxy\\njfPFjNETe10iU41rcfEQ1YV4KbyLuPa5NUAC7fa1e7CMRzuHLIpy1xuQP\\/leHZE1\\nXWrrEeEPDukHmPg2aCIAb8Vv6xxA\\/yJPblGoD3OAp\\/HMWL6JolF1wJz7AoGBAJ6I\\npkAvQ\\/334q2HdGhAX7TGeUjYotapRQrThZ49QHcqpVbVl+uEGlr0SBbv6GHWUF1s\\nQzDIfur4tcyLLhhg0FkkawJZk+sgG7TpJ2RvtEg4UyDjQKBr7osNwvRceD7cOBI0\\n2HSSo087l7MDWsujAqXBrazYbifZOFeUoP5vNQh3AoGBAOhyFhtEVbE335GZ8nND\\niXsctVG8SmHBn7+47FLLsMHdupFEVqvJUMy7QLW2zFs5Cyd9o0MsoQgtm0vgzCmu\\n9xUrBNxoIW8C+HSV6esgWXE+pGRtM4b7TK3Kpcs05U\\/ajVDzRcjVkEt5Wm3Cz+SH\\nE\\/2+gde6OAtsfnkLpswHGIcC\\n-----END PRIVATE KEY-----\\n\",\"client_email\":\"dicom-backup-service@dicom-backup.iam.gserviceaccount.com\",\"client_id\":\"117277588561687136612\",\"auth_uri\":\"https:\\/\\/accounts.google.com\\/o\\/oauth2\\/auth\",\"token_uri\":\"https:\\/\\/oauth2.googleapis.com\\/token\",\"auth_provider_x509_cert_url\":\"https:\\/\\/www.googleapis.com\\/oauth2\\/v1\\/certs\",\"client_x509_cert_url\":\"https:\\/\\/www.googleapis.com\\/robot\\/v1\\/metadata\\/x509\\/dicom-backup-service%40dicom-backup.iam.gserviceaccount.com\",\"universe_domain\":\"googleapis.com\"}', '2025-11-25 20:09:17');
INSERT INTO `hospital_data_config` (`id`, `config_key`, `config_value`, `updated_at`) VALUES ('29', 'temp_gdrive_folder', 'DICOM_Viewer_Backups', '2025-11-25 20:09:17');

-- Table: import_history
DROP TABLE IF EXISTS `import_history`;
CREATE TABLE `import_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` int(10) unsigned DEFAULT NULL,
  `file_path` varchar(1000) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size_bytes` bigint(20) NOT NULL,
  `file_hash` varchar(64) DEFAULT NULL,
  `orthanc_instance_id` varchar(255) DEFAULT NULL,
  `patient_id` varchar(64) DEFAULT NULL,
  `study_uid` varchar(255) DEFAULT NULL,
  `series_uid` varchar(255) DEFAULT NULL,
  `instance_uid` varchar(255) DEFAULT NULL,
  `status` enum('imported','failed','duplicate','skipped') DEFAULT 'imported',
  `error_message` text DEFAULT NULL,
  `imported_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_file_hash` (`file_hash`),
  KEY `idx_job_id` (`job_id`),
  KEY `idx_file_path` (`file_path`(255)),
  KEY `idx_status` (`status`),
  KEY `idx_imported_at` (`imported_at`),
  CONSTRAINT `import_history_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `import_jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: import_jobs
DROP TABLE IF EXISTS `import_jobs`;
CREATE TABLE `import_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_type` enum('initial','incremental','manual') DEFAULT 'manual',
  `source_path` varchar(500) NOT NULL,
  `total_files` int(11) DEFAULT 0,
  `files_processed` int(11) DEFAULT 0,
  `files_imported` int(11) DEFAULT 0,
  `files_failed` int(11) DEFAULT 0,
  `total_size_bytes` bigint(20) DEFAULT 0,
  `status` enum('pending','running','completed','failed','cancelled') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: imported_studies
DROP TABLE IF EXISTS `imported_studies`;
CREATE TABLE `imported_studies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_batch_id` varchar(50) DEFAULT NULL,
  `file_path` text DEFAULT NULL,
  `patient_id` varchar(100) DEFAULT NULL,
  `patient_name` varchar(200) DEFAULT NULL,
  `study_uid` varchar(200) DEFAULT NULL,
  `study_date` date DEFAULT NULL,
  `modality` varchar(20) DEFAULT NULL,
  `orthanc_id` varchar(100) DEFAULT NULL,
  `imported_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `backup_status` enum('pending','backed_up','failed') DEFAULT 'pending',
  `file_size_bytes` bigint(20) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `import_batch_id` (`import_batch_id`),
  KEY `study_uid` (`study_uid`),
  KEY `patient_id` (`patient_id`),
  KEY `backup_status` (`backup_status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: imported_studies
INSERT INTO `imported_studies` (`id`, `import_batch_id`, `file_path`, `patient_id`, `patient_name`, `study_uid`, `study_date`, `modality`, `orthanc_id`, `imported_at`, `backup_status`, `file_size_bytes`) VALUES ('1', 'IMPORT_20251125_135851_77e93fde', 'C:\\Users\\prash\\Downloads\\dicom\\series-000002\\image-000001.dcm', '0', 'Anonymized^^', '1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '2015-12-07', 'CT', 'a2390fab-3be3e31b-268f6c22-4eb2e70f-6e5d1726', '2025-11-25 19:28:52', 'pending', '2835864');
INSERT INTO `imported_studies` (`id`, `import_batch_id`, `file_path`, `patient_id`, `patient_name`, `study_uid`, `study_date`, `modality`, `orthanc_id`, `imported_at`, `backup_status`, `file_size_bytes`) VALUES ('2', 'IMPORT_20251125_135851_77e93fde', 'C:\\Users\\prash\\Downloads\\dicom\\series-000002\\image-000002.dcm', '0', 'Anonymized^^', '1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', '2015-12-07', 'CT', 'a2390fab-3be3e31b-268f6c22-4eb2e70f-6e5d1726', '2025-11-25 19:28:54', 'pending', '2835862');

-- Table: measurements
DROP TABLE IF EXISTS `measurements`;
CREATE TABLE `measurements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `study_uid` varchar(255) NOT NULL,
  `series_uid` varchar(255) NOT NULL,
  `instance_uid` varchar(255) NOT NULL,
  `tool_type` enum('length','angle','rectangle_roi','elliptical_roi','freehand_roi','probe') NOT NULL,
  `measurement_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`measurement_data`)),
  `value` varchar(100) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_study_uid` (`study_uid`),
  KEY `idx_series_uid` (`series_uid`),
  KEY `idx_instance_uid` (`instance_uid`),
  KEY `idx_tool_type` (`tool_type`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `measurements_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: medical_reports
DROP TABLE IF EXISTS `medical_reports`;
CREATE TABLE `medical_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `study_uid` varchar(255) NOT NULL,
  `patient_id` varchar(64) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `template_name` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `indication` text DEFAULT NULL,
  `technique` text DEFAULT NULL,
  `findings` text DEFAULT NULL,
  `impression` text DEFAULT NULL,
  `reporting_physician_id` int(10) unsigned DEFAULT NULL,
  `reporting_physician_name` varchar(255) DEFAULT NULL,
  `status` enum('draft','final','amended','printed') DEFAULT 'draft',
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `finalized_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_study_uid` (`study_uid`),
  KEY `idx_patient_id` (`patient_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_reporting_physician` (`reporting_physician_id`),
  CONSTRAINT `medical_reports_ibfk_1` FOREIGN KEY (`reporting_physician_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medical_reports_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: medical_reports
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('1', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'General', 'Medical Report', '', '', '', '', NULL, NULL, 'draft', '1', '2025-11-24 16:11:22', '2025-11-24 16:11:22', NULL);
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('2', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'General', 'Medical Report', '', '', '', '', NULL, NULL, 'draft', '1', '2025-11-24 16:21:15', '2025-11-24 16:21:15', NULL);
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('3', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'oih', 'oijoijoiCT chest performed with/without contrast', '{\"lungs\":\"oijoijoijThe lungs are clear bilaterally...\",\"pleura\":\"oijoijoijNo pleural effusion or pneumothorax...\",\"heart\":\"oijoijoijThe heart size is normal...\",\"mediastinum\":\"oijoijioThe mediastinum is unremarkable...\",\"bones\":\"oijoijoijVisualized osseous structures...\"}', 'oijiojioIMPRESSION:\n1.', NULL, NULL, 'draft', '1', '2025-11-24 16:32:20', '2025-11-24 16:32:20', NULL);
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('4', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'oih', 'oijoijoiCT chest performed with/without contrast', '{\"lungs\":\"oijoijoijThe lungs are clear bilaterally...\",\"pleura\":\"oijoijoijNo pleural effusion or pneumothorax...\",\"heart\":\"oijoijoijThe heart size is normal...\",\"mediastinum\":\"oijoijioThe mediastinum is unremarkable...\",\"bones\":\"oijoijoijVisualized osseous structures...\"}', 'oijiojioIMPRESSION:\n1.', NULL, NULL, 'draft', '1', '2025-11-24 16:32:50', '2025-11-24 16:32:50', NULL);
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('5', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'oih', 'oijoijoiCT chest performed with/without contrast', '{\"lungs\":\"oijoijoijThe lungs are clear bilaterally...\",\"pleura\":\"oijoijoijNo pleural effusion or pneumothorax...\",\"heart\":\"oijoijoijThe heart size is normal...\",\"mediastinum\":\"oijoijioThe mediastinum is unremarkable...\",\"bones\":\"oijoijoijVisualized osseous structures...\"}', 'oijiojioIMPRESSION:\n1.', NULL, NULL, 'draft', '1', '2025-11-24 16:33:20', '2025-11-24 16:33:20', NULL);
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('6', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'q', '1', 'lungs: 1\n\npleura: 1\n\nheart: 1\n\nmediastinum: 1\n\nbones: 1', '1', NULL, NULL, 'draft', '1', '2025-11-24 16:37:28', '2025-11-24 16:37:28', NULL);
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('7', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'Clinical indication for the study', 'CT chest performed with/without contrast', 'lungs: The lungs are clear bilaterally...\n\npleura: No pleural effusion or pneumothorax...\n\nheart: The heart size is normal...\n\nmediastinum: The mediastinum is unremarkable...\n\nbones: Visualized osseous structures...', 'IMPRESSION:\n1.', NULL, 'Prasham', 'draft', '1', '2025-11-24 16:52:09', '2025-11-24 16:52:09', NULL);
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('8', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'mri_brain', 'Medical Report', 'Clinical indication for the study', 'MRI brain with T1, T2, FLAIR, and DWI sequences', 'brain_parenchyma: The brain parenchyma is normal...\n\nwhite_matter: The white matter is unremarkable...\n\nventricles: The ventricular system is normal...\n\ncerebellum: The cerebellum and brainstem are normal...\n\nvessels: No evidence of acute infarction...', 'IMPRESSION:\n1.', NULL, '', 'draft', '1', '2025-11-24 19:14:39', '2025-11-24 19:14:39', NULL);
INSERT INTO `medical_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `indication`, `technique`, `findings`, `impression`, `reporting_physician_id`, `reporting_physician_name`, `status`, `created_by`, `created_at`, `updated_at`, `finalized_at`) VALUES ('9', '1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', 'UNKNOWN', 'Anonymized^^', 'ct_chest', 'Medical Report', 'Clinical indication for the study', 'CT chest performed with/without contrast', 'lungs: The lungs are clear bilaterally...\n\npleura: No pleural effusion or pneumothorax...\n\nheart: The heart size is normal...\n\nmediastinum: The mediastinum is unremarkable...\n\nbones: Visualized osseous structures...', 'IMPRESSION:\n1.', NULL, 'Prasham', 'draft', '1', '2025-11-25 19:30:01', '2025-11-25 19:30:01', NULL);

-- Table: prescriptions
DROP TABLE IF EXISTS `prescriptions`;
CREATE TABLE `prescriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `study_uid` varchar(255) NOT NULL,
  `patient_id` varchar(64) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `medication_name` varchar(255) NOT NULL,
  `dosage` varchar(100) NOT NULL,
  `frequency` varchar(100) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `instructions` text DEFAULT NULL,
  `prescribed_by` int(10) unsigned NOT NULL,
  `prescribed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','completed','cancelled') DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `idx_study_uid` (`study_uid`),
  KEY `idx_patient_id` (`patient_id`),
  KEY `idx_prescribed_by` (`prescribed_by`),
  KEY `idx_status` (`status`),
  CONSTRAINT `prescriptions_ibfk_1` FOREIGN KEY (`prescribed_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: prescriptions
INSERT INTO `prescriptions` (`id`, `study_uid`, `patient_id`, `patient_name`, `medication_name`, `dosage`, `frequency`, `duration`, `instructions`, `prescribed_by`, `prescribed_at`, `status`) VALUES ('3', '1.2.156.112536.1.2112.80117170048.1192854066655.6', '20150825-080809-AA30', 'Unknown Patient', '1', '1', '1', '1', '1', '1', '2025-11-24 16:52:32', 'active');

-- Table: report_versions
DROP TABLE IF EXISTS `report_versions`;
CREATE TABLE `report_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int(10) unsigned NOT NULL,
  `version_number` int(10) unsigned NOT NULL,
  `indication` text DEFAULT NULL,
  `technique` text DEFAULT NULL,
  `findings` text DEFAULT NULL,
  `impression` text DEFAULT NULL,
  `changed_by` int(10) unsigned NOT NULL,
  `change_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `changed_by` (`changed_by`),
  KEY `idx_report_id` (`report_id`),
  KEY `idx_version_number` (`version_number`),
  CONSTRAINT `report_versions_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `medical_reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_versions_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: sessions
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(128) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: study_remarks
DROP TABLE IF EXISTS `study_remarks`;
CREATE TABLE `study_remarks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `study_instance_uid` varchar(255) NOT NULL,
  `remark` text NOT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_study_uid` (`study_instance_uid`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_study_created` (`study_instance_uid`,`created_at`),
  CONSTRAINT `fk_remarks_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: study_remarks
INSERT INTO `study_remarks` (`id`, `study_instance_uid`, `remark`, `created_by`, `created_at`, `updated_at`) VALUES ('1', '1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', 'hi', '1', '2025-11-25 14:16:50', '2025-11-25 14:16:50');

-- Table: sync_configuration
DROP TABLE IF EXISTS `sync_configuration`;
CREATE TABLE `sync_configuration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orthanc_storage_path` varchar(500) NOT NULL,
  `hospital_data_path` varchar(500) DEFAULT NULL,
  `ftp_host` varchar(255) DEFAULT NULL,
  `ftp_username` varchar(100) DEFAULT NULL,
  `ftp_password` varchar(255) DEFAULT NULL,
  `ftp_port` int(11) DEFAULT 21,
  `ftp_path` varchar(500) DEFAULT '/public_html/dicom_viewer/',
  `ftp_passive` tinyint(1) DEFAULT 1,
  `sync_enabled` tinyint(1) DEFAULT 0,
  `sync_interval` int(11) DEFAULT 120,
  `monitoring_enabled` tinyint(1) DEFAULT 0,
  `monitoring_interval` int(11) DEFAULT 30,
  `last_sync_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: sync_configuration
INSERT INTO `sync_configuration` (`id`, `orthanc_storage_path`, `hospital_data_path`, `ftp_host`, `ftp_username`, `ftp_password`, `ftp_port`, `ftp_path`, `ftp_passive`, `sync_enabled`, `sync_interval`, `monitoring_enabled`, `monitoring_interval`, `last_sync_at`, `updated_at`) VALUES ('1', 'C:\\Orthanc\\OrthancStorage', NULL, NULL, NULL, NULL, '21', '/public_html/dicom_viewer/', '1', '0', '120', '0', '30', NULL, '2025-11-22 18:52:59');

-- Table: sync_history
DROP TABLE IF EXISTS `sync_history`;
CREATE TABLE `sync_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sync_type` enum('manual','scheduled','monitoring') DEFAULT 'manual',
  `destination` enum('localhost','godaddy','both') DEFAULT 'both',
  `files_synced` int(11) DEFAULT 0,
  `total_size_bytes` bigint(20) DEFAULT 0,
  `status` enum('success','failed','partial') DEFAULT 'success',
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sync_type` (`sync_type`),
  KEY `idx_status` (`status`),
  KEY `idx_started_at` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: system_settings
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','integer','boolean','json') DEFAULT 'string',
  `category` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_sensitive` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `category` (`category`),
  KEY `setting_key_2` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: system_settings
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('1', 'dicom_ae_title', 'HOSPITAL_PACS', 'string', 'dicom', 'DICOM Application Entity Title', '0', '2025-11-24 17:24:45', '2025-11-24 17:24:45');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('2', 'dicom_port', '4242', 'integer', 'dicom', 'DICOM C-STORE port number', '0', '2025-11-24 17:24:45', '2025-11-24 17:24:45');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('3', 'dicom_host', '0.0.0.0', 'string', 'dicom', 'DICOM listening host/IP address', '0', '2025-11-24 17:24:45', '2025-11-24 17:24:45');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('4', 'orthanc_url', 'http://localhost:8042', 'string', 'orthanc', 'Orthanc Server URL', '0', '2025-11-24 17:24:45', '2025-11-24 17:24:45');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('5', 'orthanc_username', 'orthanc', 'string', 'orthanc', 'Orthanc API Username', '0', '2025-11-24 17:24:45', '2025-11-24 17:24:45');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('6', 'orthanc_password', '', 'string', 'orthanc', 'Orthanc API Password', '1', '2025-11-24 17:24:45', '2025-11-24 17:24:45');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('7', 'orthanc_dicomweb_root', '/dicom-web', 'string', 'orthanc', 'DICOMweb plugin root path', '0', '2025-11-24 17:24:45', '2025-11-24 17:24:45');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('8', 'enable_technical_preview', 'true', 'boolean', 'general', 'Enable technical preview/debug mode for administrators', '0', '2025-11-24 17:24:45', '2025-11-25 19:28:17');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('9', 'hospital_name', 'General Hospital', 'string', 'hospital', 'Hospital/Institution Name', '0', '2025-11-24 17:24:45', '2025-11-24 17:24:45');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_sensitive`, `created_at`, `updated_at`) VALUES ('10', 'hospital_timezone', 'Asia/Kolkata', 'string', 'hospital', 'Hospital Timezone', '0', '2025-11-24 17:24:45', '2025-11-24 17:24:45');

-- Table: user_preferences
DROP TABLE IF EXISTS `user_preferences`;
CREATE TABLE `user_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `preference_key` varchar(100) NOT NULL,
  `preference_value` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_preference` (`user_id`,`preference_key`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `user_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` enum('admin','radiologist','technician','viewer') DEFAULT 'viewer',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table: users
INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES ('1', 'admin', '$2y$12$Aa5XJ5jZH.TH9f1Z8EHiEeVW2JhuQ.69hx6/.y.PUID2.sGCRVa1i', 'System Administrator', 'admin@hospital.com', 'admin', '1', '2025-11-25 16:55:24', '2025-11-22 18:52:59', '2025-11-25 16:55:24');
INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES ('2', 'radiologist', '$2y$12$FlxZAVkMcKyHxcffXp7b8.ohSle96MZmG0DIKuR9q2SWaVT56jVam', 'Dr. John Smith', 'radiologist@hospital.com', 'radiologist', '1', NULL, '2025-11-22 18:52:59', '2025-11-23 11:58:50');
INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES ('3', 'technician', '$2y$12$jr6cdvV7D88sbIjNTs8TE.eJU0WzfnNbg/X4bky6C.2o9pDWRkNlW', 'Sarah Johnson', 'technician@hospital.com', 'technician', '1', NULL, '2025-11-22 18:52:59', '2025-11-23 11:58:51');

-- Table: vw_active_reports
DROP TABLE IF EXISTS `vw_active_reports`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_active_reports` AS select `r`.`id` AS `id`,`r`.`study_uid` AS `study_uid`,`r`.`patient_id` AS `patient_id`,`r`.`patient_name` AS `patient_name`,`r`.`template_name` AS `template_name`,`r`.`title` AS `title`,`r`.`status` AS `status`,`u1`.`full_name` AS `created_by_name`,`u2`.`full_name` AS `reporting_physician_name`,`r`.`created_at` AS `created_at`,`r`.`updated_at` AS `updated_at`,`r`.`finalized_at` AS `finalized_at` from ((`medical_reports` `r` left join `users` `u1` on(`r`.`created_by` = `u1`.`id`)) left join `users` `u2` on(`r`.`reporting_physician_id` = `u2`.`id`)) where `r`.`status` in ('draft','final');

-- Data for table: vw_active_reports
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('1', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'General', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-24 16:11:22', '2025-11-24 16:11:22', NULL);
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('2', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'General', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-24 16:21:15', '2025-11-24 16:21:15', NULL);
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('3', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-24 16:32:20', '2025-11-24 16:32:20', NULL);
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('4', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-24 16:32:50', '2025-11-24 16:32:50', NULL);
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('5', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-24 16:33:20', '2025-11-24 16:33:20', NULL);
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('6', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-24 16:37:28', '2025-11-24 16:37:28', NULL);
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('7', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'ct_chest', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-24 16:52:09', '2025-11-24 16:52:09', NULL);
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('8', '1.2.156.112536.1.2112.80117170048.1192854066655.6', 'UNKNOWN', 'MR. SUJIT GORBAND', 'mri_brain', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-24 19:14:39', '2025-11-24 19:14:39', NULL);
INSERT INTO `vw_active_reports` (`id`, `study_uid`, `patient_id`, `patient_name`, `template_name`, `title`, `status`, `created_by_name`, `reporting_physician_name`, `created_at`, `updated_at`, `finalized_at`) VALUES ('9', '1.3.6.1.4.1.44316.6.102.1.20250704114423696.61158672119535771932', 'UNKNOWN', 'Anonymized^^', 'ct_chest', 'Medical Report', 'draft', 'System Administrator', NULL, '2025-11-25 19:30:01', '2025-11-25 19:30:01', NULL);

-- Table: vw_audit_trail
DROP TABLE IF EXISTS `vw_audit_trail`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_audit_trail` AS select `a`.`id` AS `id`,`a`.`username` AS `username`,`u`.`full_name` AS `full_name`,`a`.`action` AS `action`,`a`.`resource_type` AS `resource_type`,`a`.`resource_id` AS `resource_id`,`a`.`ip_address` AS `ip_address`,`a`.`created_at` AS `created_at` from (`audit_logs` `a` left join `users` `u` on(`a`.`user_id` = `u`.`id`)) order by `a`.`created_at` desc;

-- Data for table: vw_audit_trail
INSERT INTO `vw_audit_trail` (`id`, `username`, `full_name`, `action`, `resource_type`, `resource_id`, `ip_address`, `created_at`) VALUES ('7', 'admin', 'System Administrator', 'list', 'medical_report', NULL, '::1', '2025-11-25 19:30:39');
INSERT INTO `vw_audit_trail` (`id`, `username`, `full_name`, `action`, `resource_type`, `resource_id`, `ip_address`, `created_at`) VALUES ('6', 'admin', 'System Administrator', 'list', 'medical_report', NULL, '::1', '2025-11-25 19:30:05');
INSERT INTO `vw_audit_trail` (`id`, `username`, `full_name`, `action`, `resource_type`, `resource_id`, `ip_address`, `created_at`) VALUES ('4', 'admin', 'System Administrator', 'create', 'medical_report', '9', '::1', '2025-11-25 19:30:01');
INSERT INTO `vw_audit_trail` (`id`, `username`, `full_name`, `action`, `resource_type`, `resource_id`, `ip_address`, `created_at`) VALUES ('5', 'admin', 'System Administrator', 'list', 'medical_report', NULL, '::1', '2025-11-25 19:30:01');
INSERT INTO `vw_audit_trail` (`id`, `username`, `full_name`, `action`, `resource_type`, `resource_id`, `ip_address`, `created_at`) VALUES ('3', 'admin', 'System Administrator', 'list', 'medical_report', NULL, '::1', '2025-11-25 19:29:51');
INSERT INTO `vw_audit_trail` (`id`, `username`, `full_name`, `action`, `resource_type`, `resource_id`, `ip_address`, `created_at`) VALUES ('2', 'admin', 'System Administrator', 'list', 'medical_report', NULL, '::1', '2025-11-25 19:29:48');
INSERT INTO `vw_audit_trail` (`id`, `username`, `full_name`, `action`, `resource_type`, `resource_id`, `ip_address`, `created_at`) VALUES ('1', 'admin', 'System Administrator', 'list', 'medical_report', NULL, '::1', '2025-11-25 19:29:07');

SET FOREIGN_KEY_CHECKS=1;
