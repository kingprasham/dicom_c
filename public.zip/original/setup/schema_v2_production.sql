-- ============================================================================
-- Hospital DICOM Viewer Pro v2.0 - Production Database Schema
-- Database: dicom_viewer_v2_production
-- Created: 2025-11-19
-- Description: Fresh start database with NO patient/study caching
--              Queries Orthanc directly via DICOMweb APIs
-- ============================================================================

-- Create database
CREATE DATABASE IF NOT EXISTS `dicom_viewer_v2_production` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `dicom_viewer_v2_production`;

-- ============================================================================
-- AUTHENTICATION & USER MANAGEMENT
-- ============================================================================

-- Users table
CREATE TABLE `users` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `username` VARCHAR(50) UNIQUE NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL COMMENT 'bcrypt hash',
    `full_name` VARCHAR(255),
    `email` VARCHAR(255) UNIQUE,
    `role` ENUM('admin', 'radiologist', 'technician', 'viewer') DEFAULT 'viewer',
    `is_active` BOOLEAN DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `last_login` TIMESTAMP NULL,
    INDEX `idx_username` (`username`),
    INDEX `idx_email` (`email`),
    INDEX `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='User accounts with role-based access';

-- Sessions table (traditional session management, NOT JWT)
CREATE TABLE `sessions` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `session_id` VARCHAR(255) UNIQUE,
    `session_token` VARCHAR(255) UNIQUE COMMENT '64-char hex token',
    `user_id` INT NOT NULL,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `expires_at` DATETIME NOT NULL,
    `last_activity` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_session_token` (`session_token`),
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='User sessions for authentication';

-- Default users
INSERT INTO `users` (`username`, `password_hash`, `full_name`, `email`, `role`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@hospital.com', 'admin'),
('radiologist', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dr. John Radiologist', 'radiologist@hospital.com', 'radiologist'),
('technician', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Tech Support', 'tech@hospital.com', 'technician');
-- Default password for all: "password" (change in production!)

-- ============================================================================
-- MEDICAL REPORTS & DOCUMENTATION
-- ============================================================================

-- Medical Reports (linked to DICOM Study UID from Orthanc)
CREATE TABLE `medical_reports` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `study_instance_uid` VARCHAR(255) NOT NULL COMMENT 'DICOM Study UID from Orthanc',
    `report_type` VARCHAR(50) COMMENT 'ct_head, ct_chest, ct_abdomen, mri_brain, xray_chest',
    `indication` TEXT,
    `technique` TEXT,
    `findings` TEXT,
    `impression` TEXT,
    `reporting_physician_id` INT,
    `created_by` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `version` INT DEFAULT 1,
    `status` ENUM('draft', 'final', 'amended') DEFAULT 'draft',
    FOREIGN KEY (`reporting_physician_id`) REFERENCES `users`(`id`),
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
    INDEX `idx_study_uid` (`study_instance_uid`),
    INDEX `idx_created_by` (`created_by`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Medical reports (stored in database, NOT files)';

-- Report Version History
CREATE TABLE `report_versions` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `report_id` INT NOT NULL,
    `version` INT NOT NULL,
    `report_data` JSON COMMENT 'Full report snapshot as JSON',
    `modified_by` INT,
    `modified_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`report_id`) REFERENCES `medical_reports`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`modified_by`) REFERENCES `users`(`id`),
    INDEX `idx_report_id` (`report_id`),
    INDEX `idx_version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Version history for reports';

-- ============================================================================
-- MEASUREMENTS & ANNOTATIONS
-- ============================================================================

-- Image Measurements and Annotations
CREATE TABLE `measurements` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `series_instance_uid` VARCHAR(255) NOT NULL COMMENT 'DICOM Series UID',
    `sop_instance_uid` VARCHAR(255) COMMENT 'DICOM Instance UID',
    `measurement_type` ENUM('length', 'angle', 'roi', 'ellipse', 'rectangle', 'probe'),
    `measurement_data` JSON COMMENT '{value, unit, coordinates, etc.}',
    `created_by` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
    INDEX `idx_series_uid` (`series_instance_uid`),
    INDEX `idx_sop_uid` (`sop_instance_uid`),
    INDEX `idx_type` (`measurement_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Image measurements and annotations';

-- ============================================================================
-- CLINICAL NOTES
-- ============================================================================

-- Clinical Notes (per series or instance)
CREATE TABLE `clinical_notes` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `study_instance_uid` VARCHAR(255),
    `series_instance_uid` VARCHAR(255),
    `note_text` TEXT,
    `note_category` VARCHAR(50) COMMENT 'clinical_history, findings, etc.',
    `created_by` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
    INDEX `idx_study_uid` (`study_instance_uid`),
    INDEX `idx_series_uid` (`series_instance_uid`),
    INDEX `idx_category` (`note_category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Clinical notes for studies/series';

-- ============================================================================
-- PRESCRIPTIONS
-- ============================================================================

-- Prescriptions
CREATE TABLE `prescriptions` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `study_instance_uid` VARCHAR(255),
    `patient_identifier` VARCHAR(255) COMMENT 'From DICOM PatientID',
    `prescription_data` JSON,
    `prescribed_by` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`prescribed_by`) REFERENCES `users`(`id`),
    INDEX `idx_study_uid` (`study_instance_uid`),
    INDEX `idx_patient_id` (`patient_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Medical prescriptions';

-- ============================================================================
-- USER PREFERENCES
-- ============================================================================

-- User Preferences
CREATE TABLE `user_preferences` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT NOT NULL,
    `preference_key` VARCHAR(100) NOT NULL,
    `preference_value` JSON,
    `updated_at` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_user_pref` (`user_id`, `preference_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='User-specific settings and preferences';

-- ============================================================================
-- AUDIT LOGS (HIPAA COMPLIANCE)
-- ============================================================================

-- Audit Logs
CREATE TABLE `audit_logs` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT,
    `action` VARCHAR(100) COMMENT 'login, view_study, export_image, etc.',
    `resource_type` VARCHAR(50) COMMENT 'study, report, patient',
    `resource_id` VARCHAR(255) COMMENT 'Study UID, Report ID, etc.',
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_action` (`action`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_resource` (`resource_type`, `resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Audit trail for compliance (HIPAA)';

-- ============================================================================
-- NEW: AUTOMATED SYNC CONFIGURATION
-- ============================================================================

-- Sync Configuration
CREATE TABLE `sync_configuration` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `orthanc_storage_path` VARCHAR(500) NOT NULL COMMENT 'Path to Orthanc storage directory',
    `auto_sync_enabled` BOOLEAN DEFAULT TRUE,
    `sync_interval_minutes` INT DEFAULT 5,
    `sync_to_localhost` BOOLEAN DEFAULT TRUE,
    `sync_to_godaddy` BOOLEAN DEFAULT TRUE,
    `godaddy_ftp_host` VARCHAR(255),
    `godaddy_ftp_username` VARCHAR(255),
    `godaddy_ftp_password` VARCHAR(255) COMMENT 'Encrypted',
    `godaddy_ftp_path` VARCHAR(500),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `last_tested` TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Configuration for automated directory sync';

-- Default sync configuration
INSERT INTO `sync_configuration` (`orthanc_storage_path`, `auto_sync_enabled`, `sync_interval_minutes`) VALUES
('C:\\Orthanc\\OrthancStorage', FALSE, 5);

-- Sync History
CREATE TABLE `sync_history` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `sync_started_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `sync_completed_at` TIMESTAMP NULL,
    `sync_destination` ENUM('localhost', 'godaddy') NOT NULL,
    `files_synced` INT DEFAULT 0,
    `total_size_mb` DECIMAL(10,2) DEFAULT 0,
    `status` ENUM('running', 'completed', 'failed') DEFAULT 'running',
    `error_message` TEXT NULL,
    INDEX `idx_started` (`sync_started_at`),
    INDEX `idx_destination` (`sync_destination`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='History of sync operations';

-- ============================================================================
-- NEW: GOOGLE DRIVE BACKUP CONFIGURATION
-- ============================================================================

-- Google Drive Backup Configuration
CREATE TABLE `gdrive_backup_config` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `client_id` VARCHAR(500),
    `client_secret` VARCHAR(500) COMMENT 'Encrypted',
    `refresh_token` TEXT COMMENT 'Encrypted',
    `folder_name` VARCHAR(255) DEFAULT 'DICOM_Viewer_Backups',
    `auto_backup_enabled` BOOLEAN DEFAULT TRUE,
    `backup_frequency` ENUM('daily', 'weekly', 'monthly') DEFAULT 'daily',
    `backup_time` TIME DEFAULT '02:00:00',
    `backup_database` BOOLEAN DEFAULT TRUE,
    `backup_php_files` BOOLEAN DEFAULT TRUE,
    `backup_js_files` BOOLEAN DEFAULT TRUE,
    `backup_config_files` BOOLEAN DEFAULT TRUE,
    `retention_days` INT DEFAULT 30,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Google Drive backup configuration';

-- Default backup configuration
INSERT INTO `gdrive_backup_config` (`folder_name`, `auto_backup_enabled`, `backup_frequency`, `retention_days`) VALUES
('DICOM_Viewer_Backups', FALSE, 'daily', 30);

-- Backup History
CREATE TABLE `backup_history` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `backup_started_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `backup_completed_at` TIMESTAMP NULL,
    `backup_filename` VARCHAR(255),
    `gdrive_file_id` VARCHAR(255),
    `backup_size_mb` DECIMAL(10,2),
    `status` ENUM('running', 'completed', 'failed') DEFAULT 'running',
    `error_message` TEXT NULL,
    `can_restore` BOOLEAN DEFAULT TRUE,
    INDEX `idx_started` (`backup_started_at`),
    INDEX `idx_filename` (`backup_filename`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='History of Google Drive backups';

-- ============================================================================
-- SUMMARY
-- ============================================================================

/*
REMOVED TABLES (from old system - NO LONGER NEEDED):
- cached_patients       → Query Orthanc via DICOMweb instead
- cached_studies        → Query Orthanc via DICOMweb instead
- dicom_instances       → Orthanc handles this natively

NEW TABLES (v2 additions):
- sync_configuration    → Configure automated directory sync
- sync_history          → Track sync operations
- gdrive_backup_config  → Configure Google Drive backups
- backup_history        → Track backup operations

KEPT TABLES (from old system):
- users                 → User authentication
- sessions              → Session management
- medical_reports       → Medical reports (NOW in database, not files)
- report_versions       → Report version history
- measurements          → Image measurements
- clinical_notes        → Clinical notes
- prescriptions         → Prescriptions
- user_preferences      → User settings
- audit_logs            → Compliance tracking

BENEFITS:
✅ 90% smaller database (no DICOM metadata cache)
✅ Always up-to-date data (queries Orthanc in real-time)
✅ No sync scripts needed
✅ Automated backups to Google Drive
✅ Automated file syncing to localhost & GoDaddy
✅ Production-ready
*/

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
