-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2025 at 10:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dicom`
--

-- --------------------------------------------------------

--
-- Table structure for table `cached_patients`
--

CREATE TABLE `cached_patients` (
  `id` int(11) NOT NULL,
  `patient_id` varchar(255) DEFAULT NULL,
  `orthanc_id` varchar(255) DEFAULT NULL,
  `patient_name` varchar(500) DEFAULT NULL,
  `patient_sex` char(1) DEFAULT NULL,
  `patient_birth_date` date DEFAULT NULL,
  `study_count` int(11) DEFAULT 0,
  `last_study_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_synced` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cached_studies`
--

CREATE TABLE `cached_studies` (
  `id` int(11) NOT NULL,
  `study_instance_uid` varchar(255) DEFAULT NULL,
  `orthanc_id` varchar(255) DEFAULT NULL,
  `patient_id` varchar(255) DEFAULT NULL,
  `study_date` date DEFAULT NULL,
  `study_time` time DEFAULT NULL,
  `study_description` text DEFAULT NULL,
  `study_name` varchar(500) DEFAULT NULL,
  `accession_number` varchar(255) DEFAULT NULL,
  `modality` varchar(50) DEFAULT NULL,
  `series_count` int(11) DEFAULT 0,
  `instance_count` int(11) DEFAULT 0,
  `instances_count` int(11) DEFAULT 0,
  `last_synced` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `study_id` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dicom_instances`
--

CREATE TABLE `dicom_instances` (
  `id` int(11) NOT NULL,
  `instance_id` varchar(255) DEFAULT NULL,
  `orthanc_study_id` varchar(255) DEFAULT NULL,
  `study_uid` varchar(255) DEFAULT NULL,
  `series_uid` varchar(255) DEFAULT NULL,
  `sop_uid` varchar(255) DEFAULT NULL,
  `instance_number` int(11) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `session_token` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `session_id`, `session_token`, `user_id`, `ip_address`, `user_agent`, `created_at`, `expires_at`, `last_activity`) VALUES
(1, '7jg8ktsoc2ibc2aigf5oro8j6o', 'a9d366ff55e6e4113d70109e2bd7705436b9b9a250d566d5fcb3331351d7b1fe', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', '2025-11-07 09:05:48', '2025-11-07 10:05:48', '2025-11-07 09:05:48');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `session_token` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role` enum('admin','radiologist','technician','viewer') DEFAULT 'viewer',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `session_token`, `full_name`, `email`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$x.Jj6TOBU0GPzJ3jd8BmSeh3vY5hYhAFO6ZJTMmHHlkaxwL5ra9XK', NULL, 'Administrator', 'admin@example.com', 'admin', 1, '2025-11-07 03:35:48', '2025-10-13 10:05:49', '2025-11-07 09:05:48'),
(2, 'test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, 'Test User', 'test@example.com', 'admin', 1, NULL, '2025-11-05 12:12:40', '2025-11-05 12:12:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cached_patients`
--
ALTER TABLE `cached_patients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `patient_id` (`patient_id`),
  ADD KEY `idx_patient_name` (`patient_name`(255));

--
-- Indexes for table `cached_studies`
--
ALTER TABLE `cached_studies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `study_instance_uid` (`study_instance_uid`),
  ADD KEY `idx_patient` (`patient_id`),
  ADD KEY `idx_study_date` (`study_date`),
  ADD KEY `idx_modality` (`modality`);

--
-- Indexes for table `dicom_instances`
--
ALTER TABLE `dicom_instances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `instance_id` (`instance_id`),
  ADD KEY `idx_orthanc_study` (`orthanc_study_id`),
  ADD KEY `idx_study_uid` (`study_uid`),
  ADD KEY `idx_series_uid` (`series_uid`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_session_id` (`session_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cached_patients`
--
ALTER TABLE `cached_patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cached_studies`
--
ALTER TABLE `cached_studies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dicom_instances`
--
ALTER TABLE `dicom_instances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
